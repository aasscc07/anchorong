from urllib.request import urlopen
from bs4 import BeautifulSoup
import pickle
import os
import sys

L1 = []

response = urlopen("https://grafolio.naver.com/wallpaper.grfl")
soup = BeautifulSoup(response,'html.parser')
NUM_NUM = 0
for anchor in soup.find_all('img'):
    L1.append(anchor.get('src'))
    NUM_NUM += 1
    
file_1 = open("C:/anchorong/web_ads.txt",'w')
file_1.write(str(NUM_NUM))
file_2 = []
for i in range(NUM_NUM):
    file_2.append(open("D:/coding/crawling_image/image_web_ads/{}.txt".format(i+1),'w'))
    file_2[i].write(str(L1[i]))

file_1.close()

os.system("start C:\\anchorong\\web_crawling.exe")





# root = Tk()
# root.title("anchorong")
# root.geometry("1080x720")
# root.resizable(False,False)

# a = Entry(root,width=50)
# a.pack()
# def button_command():
#     m = 0
#     m = a.get()
#     b = "https://www.google.com/search?q={0}&sxsrf=ALeKk00WNcjQVNZUy4MgSO3TFos-DRrgtw:1616912836207&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiSg_DZrdLvAhXD7WEKHYZvAdwQ_AUoAXoECAEQAw&cshid=1616912861392132&biw=1920&bih=937".format(m)
#     print(b)


# c = Button(root,text="button",command=button_command)
# c.pack()
# c = Button(root,text="button",command=)
# b = "https://www.google.com/search?q={0}&sxsrf=ALeKk00WNcjQVNZUy4MgSO3TFos-DRrgtw:1616912836207&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiSg_DZrdLvAhXD7WEKHYZvAdwQ_AUoAXoECAEQAw&cshid=1616912861392132&biw=1920&bih=937".format(a.get)

# file_file = open("file.txt","rb")
# # sentence = input("입력>>:")
# # print(sentence,file=file_file)
# # file_file.close()
# file_1 = pickle.load(file_file)
# print(file_1)
# file_file.close()

#root.mainloop()