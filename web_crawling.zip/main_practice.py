from urllib.request import urlopen
from bs4 import BeautifulSoup
from tkinter import *
import pickle
import os
import sys


text_1 = str(input("web ads>>:"))



L1 = []
response = urlopen(str(text_1))

soup = BeautifulSoup(response,'html.parser')
NUM_NUM = 0
for anchor in soup.find_all('img'):
    L1.append(anchor.get('src'))
    NUM_NUM += 1
    
file_1 = open("C:/anchorong/web_ads.txt",'w')
file_1.write(str(NUM_NUM))
file_2 = []
for i in range(NUM_NUM):
    file_2.append(open("D:/coding/crawling_image/image_web_ads/{}.txt".format(i+1),'w'))
    file_2[i].write(str(L1[i]))

file_1.close()

os.system("start C:\\anchorong\\web_crawling.exe")

